# regwatch – tygodniowy monitoring zmian regulacyjnych (środowisko, zdrowie, BHP, ESG)

Raz w tygodniu skanuje wskazane strony, porównuje je ze stanem z poprzedniego runu
i raportuje **nowe** oraz **zaktualizowane** publikacje wraz z ustrukturyzowanymi polami.

## Jak to działa
```
sources.yaml ─► fetch (robots.txt, retry) ─► extract (rss/json/html/page)
             ─► classify (taksonomia EN+PL) ─► store (SQLite: hash treści)
             ─► status: new | updated | baseline | unchanged ─► report (MD + CSV + JSON)
```
* **Nowe** – klucz (źródło + URL) nie istniał w bazie.
* **Zaktualizowane** – ten sam URL, ale zmienił się hash (tytuł/opis/data aktualizacji); pole
  `change_note` mówi co dokładnie (np. jakie zdania dodano do opisu).
* **page** – dla stron bez listy publikacji: diff tekstu całej strony, raportowane są dodane linie.
* **Pierwszy run źródła** zapisuje stan bazowy; raportowane są tylko pozycje z ostatnich
  `lookback_days` dni, reszta dostaje status `baseline` (bez zalewu raportu).
* Raportowane są tylko pozycje z trafieniem w taksonomii (`relevance > 0`); reszta jest zapisywana w bazie,
  więc jeśli zmiana uczyni ją istotną, pojawi się jako „zaktualizowana”.

## Pola wyjściowe (items.csv / items.json)
`status, jurisdiction, state, source_name, title, url, published, updated, effective_date,
domain (environment/health/safety/sustainability), topics, action_type
(final_rule/proposed_rule/guidance/enforcement/hearing_event/amendment), keywords,
relevance, summary, change_note, first_seen`

## Uruchomienie
```bash
pip install -r requirements.txt
python -m regwatch                      # wszystkie włączone źródła
python -m regwatch --only fr_epa        # jedno źródło
python -m unittest discover -s tests    # testy (offline)
```
Wyniki: `output/<data>/report.md|items.csv|items.json`, stan: `data/state.db`.

## Harmonogram
* **GitHub Actions** – `.github/workflows/weekly.yml` (poniedziałek 05:00 UTC), commituje bazę i raport do repo.
* **Cron:** `0 6 * * 1 cd /ścieżka/regwatch && python -m regwatch`

## Dodawanie źródeł i dostrajanie
1. Dopisz wpis w `config/sources.yaml` (RSS/JSON bez selektorów to najstabilniejsza opcja;
   dla HTML podaj selektory CSS, `selektor@atrybut` pobiera atrybut, np. `time@datetime`).
2. Rozszerz `config/taxonomy.yaml` o słowa kluczowe swojej branży/jurysdykcji.
3. Stan USA ustawiasz polem `state: CA` (lub `jurisdiction: US-CA`).

## Uwagi
* Przykładowe adresy/selektory w `sources.yaml` trzeba zweryfikować na żywych stronach – kod
  testowano na danych syntetycznych (środowisko budowy nie miało dostępu do sieci).
* Ustaw prawdziwy kontakt w `UA` w `regwatch/fetch.py`. Skaner respektuje robots.txt i robi przerwy między żądaniami;
  sprawdź regulaminy serwisów, zanim je zeskanujesz.
* Strony renderowane JavaScriptem (SPA) wymagają Playwrighta – nie jest wbudowany; najpierw sprawdź, czy serwis ma RSS/API.
* Naturalne rozszerzenie: warstwa LLM (np. API Claude) do streszczeń i precyzyjniejszej klasyfikacji w miejsce słów kluczowych.
