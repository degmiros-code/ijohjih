import os, sys, tempfile, unittest
from datetime import date

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from regwatch.classify import Taxonomy
from regwatch.pipeline import process_source
from regwatch.store import Store

ROOT = os.path.join(os.path.dirname(__file__), "..")

RSS_V1 = b"""<?xml version="1.0"?><rss version="2.0"><channel>
<item><title>Final rule: PFAS limits in drinking water</title><link>https://ex.gov/a</link>
<pubDate>Mon, 19 Oct 2026 10:00:00 GMT</pubDate>
<description>The rule is effective January 5, 2027 and sets PFAS limits.</description></item>
<item><title>Office holiday schedule</title><link>https://ex.gov/b</link>
<pubDate>Mon, 19 Oct 2026 10:00:00 GMT</pubDate><description>Closed Monday.</description></item>
<item><title>Old OSHA notice</title><link>https://ex.gov/old</link>
<pubDate>Mon, 01 Jan 2024 10:00:00 GMT</pubDate><description>OSHA workplace safety.</description></item>
</channel></rss>"""

RSS_V2 = RSS_V1.replace(
    b"sets PFAS limits.</description></item>",
    b"sets PFAS limits. Compliance deadline extended.</description></item>"
).replace(b"</channel>", b"""<item><title>Proposed rule: heat illness prevention (OSHA)</title>
<link>https://ex.gov/c</link><pubDate>Mon, 26 Oct 2026 08:00:00 GMT</pubDate>
<description>Public comment open on workplace heat illness standard.</description></item></channel>""")

SRC = {"id": "t", "name": "Test CA", "jurisdiction": "US-CA", "state": "CA", "type": "rss", "url": "https://ex.gov/"}


class Pipeline(unittest.TestCase):
    def setUp(self):
        self.tax = Taxonomy(os.path.join(ROOT, "config/taxonomy.yaml"))
        self.store = Store(os.path.join(tempfile.mkdtemp(), "s.db"))

    def test_full_cycle(self):
        # run 1: baseline – stary wpis pominięty, nieistotny odfiltrowany
        r1 = process_source(SRC, RSS_V1, self.store, self.tax, date(2026, 10, 20), 30)
        self.assertEqual([i.title for i in r1], ["Final rule: PFAS limits in drinking water"])
        a = r1[0]
        self.assertEqual((a.status, a.state, a.domain, a.action_type), ("new", "California", "environment", "final_rule"))
        self.assertIn("water", a.topics)
        self.assertEqual(a.effective_date, "2027-01-05")

        # run 2 bez zmian -> pusto
        self.assertEqual(process_source(SRC, RSS_V1, self.store, self.tax, date(2026, 10, 21), 30), [])

        # run 3: nowy wpis + zaktualizowany opis
        r3 = process_source(SRC, RSS_V2, self.store, self.tax, date(2026, 10, 26), 30)
        by = {i.url: i for i in r3}
        self.assertEqual(by["https://ex.gov/c"].status, "new")
        self.assertEqual(by["https://ex.gov/c"].domain, "safety")
        self.assertEqual(by["https://ex.gov/a"].status, "updated")
        self.assertIn("Compliance deadline extended", by["https://ex.gov/a"].change_note)

    def test_html_and_page_watch(self):
        html = b"<article><h2><a href='/x'>EPA emissions amendment</a></h2><time datetime='2026-10-25'></time><p>Update.</p></article>"
        src = {"id": "h", "name": "H", "jurisdiction": "US-Federal", "state": None, "type": "html",
               "url": "https://ex.gov/n/", "selectors": {"item": "article", "title": "h2 a", "url": "h2 a@href",
                                                         "date": "time@datetime", "summary": "p"}}
        r = process_source(src, html, self.store, self.tax, date(2026, 10, 26), 30)
        self.assertEqual((r[0].url, r[0].published, r[0].state), ("https://ex.gov/x", "2026-10-25", None))

        page = {"id": "p", "name": "P", "jurisdiction": "US-TX", "state": "TX", "type": "page", "url": "https://ex.gov/p"}
        p1, p2 = b"<body><p>Intro text here</p></body>", b"<body><p>Intro text here</p><p>New hazardous waste rule adopted</p></body>"
        self.assertEqual(process_source(page, p1, self.store, self.tax, date(2026, 10, 19), 30), [])
        r = process_source(page, p2, self.store, self.tax, date(2026, 10, 26), 30)
        self.assertEqual((r[0].status, r[0].state), ("updated", "Texas"))


if __name__ == "__main__":
    unittest.main()
