from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Optional


@dataclass
class Item:
    source_id: str
    source_name: str
    jurisdiction: str
    state: Optional[str]            # nazwa stanu USA lub None
    title: str
    url: str
    published: Optional[str] = None  # ISO date
    updated: Optional[str] = None
    summary: str = ""
    domain: Optional[str] = None     # environment / health / safety / sustainability
    topics: list = field(default_factory=list)
    action_type: Optional[str] = None
    effective_date: Optional[str] = None
    keywords: list = field(default_factory=list)
    relevance: int = 0
    status: str = "unchanged"        # new / updated / baseline / unchanged
    change_note: str = ""
    first_seen: Optional[str] = None
    last_seen: Optional[str] = None

    def to_dict(self):
        return asdict(self)
