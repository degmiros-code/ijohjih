"""Eksport: JSON, CSV (płaskie, do Excela/BI) i raport Markdown."""
from __future__ import annotations
import csv
import json
import os
from collections import defaultdict

FIELDS = ["status", "jurisdiction", "state", "source_name", "title", "url", "published", "updated",
          "effective_date", "domain", "topics", "action_type", "keywords", "relevance",
          "summary", "change_note", "first_seen"]


def write_all(items: list, errors: dict, out_dir: str, run_date: str) -> str:
    d = os.path.join(out_dir, run_date)
    os.makedirs(d, exist_ok=True)
    items = sorted(items, key=lambda i: (i.jurisdiction, i.domain or "", -i.relevance))

    with open(os.path.join(d, "items.json"), "w", encoding="utf-8") as f:
        json.dump([i.to_dict() for i in items], f, ensure_ascii=False, indent=2)

    with open(os.path.join(d, "items.csv"), "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS, extrasaction="ignore")
        w.writeheader()
        for i in items:
            row = i.to_dict()
            row["topics"], row["keywords"] = ", ".join(i.topics), ", ".join(i.keywords)
            w.writerow(row)

    lines = [f"# Przegląd zmian regulacyjnych EHS&S – {run_date}", "",
             f"Nowe: **{sum(i.status == 'new' for i in items)}**, "
             f"zaktualizowane: **{sum(i.status == 'updated' for i in items)}**", ""]
    groups = defaultdict(list)
    for i in items:
        groups[i.state or i.jurisdiction].append(i)
    for g in sorted(groups):
        lines += [f"## {g}", ""]
        for i in groups[g]:
            tag = "🆕 NOWE" if i.status == "new" else "✏️ ZAKTUALIZOWANE"
            lines.append(f"### {tag}: [{i.title}]({i.url})")
            lines.append(f"- **Źródło:** {i.source_name}  |  **Opublikowano:** {i.published or '—'}"
                         + (f"  |  **Zaktualizowano:** {i.updated}" if i.updated else ""))
            lines.append(f"- **Kategoria:** {i.domain} → {', '.join(i.topics)}"
                         f"  |  **Typ:** {i.action_type or '—'}"
                         + (f"  |  **Wejście w życie:** {i.effective_date}" if i.effective_date else ""))
            if i.summary:
                lines.append(f"- **Opis:** {i.summary[:400]}{'…' if len(i.summary) > 400 else ''}")
            if i.change_note:
                lines.append(f"- **Co się zmieniło:** {i.change_note}")
            lines.append("")
    if errors:
        lines += ["## ⚠️ Błędy źródeł", ""] + [f"- `{k}`: {v}" for k, v in errors.items()] + [""]
    path = os.path.join(d, "report.md")
    with open(path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    return path
