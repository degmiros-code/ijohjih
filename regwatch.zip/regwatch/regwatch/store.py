"""Stan między runami (SQLite): pozycje + migawki stron."""
from __future__ import annotations
import difflib
import hashlib
import json
import re
import sqlite3
from typing import Optional

from .models import Item


def item_key(item: Item) -> str:
    return hashlib.sha1(f"{item.source_id}|{item.url or item.title}".encode()).hexdigest()


def content_hash(item: Item) -> str:
    blob = json.dumps([item.title, item.summary, item.updated, item.published], ensure_ascii=False)
    return hashlib.sha1(blob.encode()).hexdigest()


def _sentences(t: str) -> list:
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+", t or "") if s.strip()]


def describe_change(old: dict, new: Item) -> str:
    notes = []
    for f, label in (("title", "tytuł"), ("updated", "data aktualizacji"), ("published", "data publikacji")):
        if old.get(f) != getattr(new, f):
            notes.append(f"{label}: „{old.get(f)}” → „{getattr(new, f)}”")
    if old.get("summary") != new.summary:
        added = [l[2:] for l in difflib.ndiff(_sentences(old.get("summary")), _sentences(new.summary))
                 if l.startswith("+ ")]
        notes.append("opis – dodano: " + (" ".join(added)[:300] if added else "(przeredagowano)"))
    return "; ".join(notes) or "zmiana treści"


class Store:
    def __init__(self, path: str):
        self.db = sqlite3.connect(path)
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS items(
            key TEXT PRIMARY KEY, source_id TEXT, hash TEXT, data TEXT,
            first_seen TEXT, last_seen TEXT);
        CREATE TABLE IF NOT EXISTS pages(
            source_id TEXT PRIMARY KEY, text TEXT, last_seen TEXT);
        """)

    def has_items(self, source_id: str) -> bool:
        return self.db.execute("SELECT 1 FROM items WHERE source_id=? LIMIT 1", (source_id,)).fetchone() is not None

    def upsert(self, item: Item, now: str) -> tuple[str, str]:
        """Zwraca (status, change_note): new | updated | unchanged."""
        key, h = item_key(item), content_hash(item)
        row = self.db.execute("SELECT hash, data, first_seen FROM items WHERE key=?", (key,)).fetchone()
        if row is None:
            item.first_seen = item.last_seen = now
            self._write(key, item, h)
            return "new", ""
        old_hash, old_data, first = row
        item.first_seen, item.last_seen = first, now
        if old_hash == h:
            self.db.execute("UPDATE items SET last_seen=? WHERE key=?", (now, key))
            self.db.commit()
            return "unchanged", ""
        note = describe_change(json.loads(old_data), item)
        self._write(key, item, h)
        return "updated", note

    def _write(self, key: str, item: Item, h: str):
        self.db.execute(
            "INSERT OR REPLACE INTO items VALUES(?,?,?,?,?,?)",
            (key, item.source_id, h, json.dumps(item.to_dict(), ensure_ascii=False), item.first_seen, item.last_seen),
        )
        self.db.commit()

    # --- page-watch
    def get_page(self, source_id: str) -> Optional[list]:
        r = self.db.execute("SELECT text FROM pages WHERE source_id=?", (source_id,)).fetchone()
        return json.loads(r[0]) if r else None

    def save_page(self, source_id: str, lines: list, now: str):
        self.db.execute("INSERT OR REPLACE INTO pages VALUES(?,?,?)", (source_id, json.dumps(lines, ensure_ascii=False), now))
        self.db.commit()


def page_diff(old: list, new: list) -> tuple[list, list]:
    added, removed = [], []
    for l in difflib.ndiff(old, new):
        if l.startswith("+ "):
            added.append(l[2:])
        elif l.startswith("- "):
            removed.append(l[2:])
    return added, removed
