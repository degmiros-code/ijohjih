import time
import urllib.parse
import urllib.robotparser

import requests

UA = "RegWatchBot/1.0 (+kontakt: ustaw-swoj-email@example.com)"
_robots: dict = {}


def allowed(url: str) -> bool:
    """Respektuj robots.txt."""
    p = urllib.parse.urlparse(url)
    base = f"{p.scheme}://{p.netloc}"
    if base not in _robots:
        rp = urllib.robotparser.RobotFileParser()
        rp.set_url(base + "/robots.txt")
        try:
            rp.read()
        except Exception:
            rp = None
        _robots[base] = rp
    rp = _robots[base]
    return True if rp is None else rp.can_fetch(UA, url)


def fetch(url: str, params=None, retries: int = 3, delay: float = 2.0, timeout: int = 30) -> bytes:
    if not allowed(url):
        raise PermissionError(f"robots.txt blokuje: {url}")
    last = None
    for i in range(retries):
        try:
            r = requests.get(
                url, params=params, timeout=timeout,
                headers={"User-Agent": UA, "Accept-Language": "en,pl;q=0.8"},
            )
            r.raise_for_status()
            time.sleep(delay)
            return r.content
        except requests.RequestException as e:
            last = e
            time.sleep(delay * (2 ** i))
    raise last
