from __future__ import annotations
import argparse
import logging
import os
from datetime import date

import yaml

from .classify import Taxonomy
from .fetch import fetch
from .pipeline import process_source
from .report import write_all
from .store import Store

log = logging.getLogger("regwatch")


def main():
    ap = argparse.ArgumentParser(description="Tygodniowy skan zmian regulacyjnych EHS&S")
    ap.add_argument("--config", default="config/sources.yaml")
    ap.add_argument("--taxonomy", default="config/taxonomy.yaml")
    ap.add_argument("--db", default="data/state.db")
    ap.add_argument("--out", default="output")
    ap.add_argument("--only", help="uruchom tylko wskazane id źródła")
    args = ap.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    with open(args.config, encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    os.makedirs(os.path.dirname(args.db) or ".", exist_ok=True)
    store, tax, today = Store(args.db), Taxonomy(args.taxonomy), date.today()

    items, errors = [], {}
    for src in cfg["sources"]:
        if not src.get("enabled", True) or (args.only and src["id"] != args.only):
            continue
        try:
            log.info("Skanuję %s", src["id"])
            content = fetch(src["url"], params=src.get("params"), delay=cfg.get("request_delay_s", 2.0))
            found = process_source(src, content, store, tax, today, cfg.get("lookback_days", 30))
            log.info("  %s: %d istotnych zmian", src["id"], len(found))
            items += found
        except Exception as e:                     # jedno źródło nie może wywrócić całego runa
            log.exception("Błąd źródła %s", src["id"])
            errors[src["id"]] = f"{type(e).__name__}: {e}"

    path = write_all(items, errors, args.out, today.isoformat())
    log.info("Raport: %s (pozycji: %d, błędów: %d)", path, len(items), len(errors))


if __name__ == "__main__":
    main()
