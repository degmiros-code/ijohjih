"""Przetwarzanie jednego źródła: ekstrakcja -> klasyfikacja -> wykrycie zmian."""
from __future__ import annotations
from datetime import date, timedelta

from .classify import Taxonomy, effective_date, state_name
from .extract import PARSERS, page_text
from .models import Item
from .store import Store, page_diff


def _base(src: dict, **kw) -> Item:
    return Item(
        source_id=src["id"], source_name=src["name"], jurisdiction=src["jurisdiction"],
        state=state_name(src), **kw,
    )


def _enrich(item: Item, tax: Taxonomy):
    c = tax.classify(item.title, item.summary)
    item.domain, item.topics, item.keywords = c["domain"], c["topics"], c["keywords"]
    item.relevance, item.action_type = c["relevance"], c["action_type"]
    item.effective_date = effective_date(f"{item.title}. {item.summary}")


def process_source(src: dict, content: bytes, store: Store, tax: Taxonomy,
                   today: date, lookback_days: int = 30) -> list[Item]:
    """Zwraca pozycje istotne (relevance>0) o statusie new/updated."""
    now = today.isoformat()

    # --- tryb page-watch: diff tekstu całej strony
    if src["type"] == "page":
        lines = page_text(content)
        old = store.get_page(src["id"])
        store.save_page(src["id"], lines, now)
        if old is None:                      # pierwszy run = tylko migawka bazowa
            return []
        added, removed = page_diff(old, lines)
        if not added:
            return []
        item = _base(src, title=f"{src['name']}: zmiany na stronie", url=src["url"],
                     updated=now, summary=" ".join(added)[:1500], status="updated",
                     change_note=f"+{len(added)} / −{len(removed)} linii",
                     first_seen=now, last_seen=now)
        _enrich(item, tax)
        return [item] if item.relevance > 0 else []

    # --- tryb listy pozycji
    raw = PARSERS[src["type"]](content, src)
    first_run = not store.has_items(src["id"])
    cutoff = today - timedelta(days=lookback_days)
    out = []
    for r in raw:
        item = _base(src, title=r.title, url=r.url, published=r.published,
                     updated=r.updated, summary=r.summary)
        _enrich(item, tax)
        status, note = store.upsert(item, now)
        if first_run and status == "new":
            recent = item.published and date.fromisoformat(item.published) >= cutoff
            status = "new" if recent else "baseline"
        item.status, item.change_note = status, note
        if item.relevance > 0 and status in ("new", "updated"):
            out.append(item)
    return out
