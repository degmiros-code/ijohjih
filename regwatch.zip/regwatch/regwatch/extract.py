"""Ekstrakcja surowych pozycji (tytuł, link, daty, opis) ze źródeł."""
from __future__ import annotations
import json
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from typing import Optional
from urllib.parse import urljoin

from bs4 import BeautifulSoup
from dateutil import parser as dparser


@dataclass
class Raw:
    title: str
    url: str
    published: Optional[str] = None
    updated: Optional[str] = None
    summary: str = ""


def to_date(s) -> Optional[str]:
    if not s:
        return None
    try:
        return dparser.parse(str(s), fuzzy=True).date().isoformat()
    except (ValueError, OverflowError):
        return None


def _clean(html: str) -> str:
    return re.sub(r"\s+", " ", BeautifulSoup(html or "", "html.parser").get_text(" ", strip=True))


def _local(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def parse_rss(content: bytes, src: dict) -> list[Raw]:
    """RSS 2.0 i Atom – bez zewnętrznych zależności."""
    root = ET.fromstring(content)
    out = []
    for el in root.iter():
        if _local(el.tag) not in ("item", "entry"):
            continue
        f: dict = {}
        for ch in el:
            k = _local(ch.tag)
            if k == "link":
                f.setdefault("link", ch.get("href") or (ch.text or "").strip())
            else:
                f.setdefault(k, (ch.text or "").strip())
        out.append(Raw(
            title=_clean(f.get("title", "")),
            url=urljoin(src["url"], f.get("link", "")),
            published=to_date(f.get("pubDate") or f.get("published") or f.get("date")),
            updated=to_date(f.get("updated")),
            summary=_clean(f.get("description") or f.get("summary") or f.get("content") or ""),
        ))
    return [r for r in out if r.title]


def _pick(node, spec):
    if not spec:
        return None
    sel, _, attr = spec.partition("@")
    el = node.select_one(sel) if sel else node
    if el is None:
        return None
    return el.get(attr) if attr else el.get_text(" ", strip=True)


def parse_html(content: bytes, src: dict) -> list[Raw]:
    s = src["selectors"]
    soup = BeautifulSoup(content, "html.parser")
    out = []
    for node in soup.select(s["item"]):
        title = _pick(node, s.get("title"))
        href = _pick(node, s.get("url"))
        if not title:
            continue
        out.append(Raw(
            title=re.sub(r"\s+", " ", title),
            url=urljoin(src["url"], href or ""),
            published=to_date(_pick(node, s.get("date"))),
            updated=to_date(_pick(node, s.get("updated"))),
            summary=re.sub(r"\s+", " ", _pick(node, s.get("summary")) or ""),
        ))
    return out


def _dig(obj, path: str):
    for part in path.split("."):
        if obj is None:
            return None
        obj = obj.get(part) if isinstance(obj, dict) else None
    return obj


def parse_json(content: bytes, src: dict) -> list[Raw]:
    data = json.loads(content)
    rows = _dig(data, src["items_path"]) if src.get("items_path") else data
    f = src["fields"]
    out = []
    for row in rows or []:
        title = _dig(row, f["title"])
        if not title:
            continue
        out.append(Raw(
            title=_clean(str(title)),
            url=str(_dig(row, f["url"]) or ""),
            published=to_date(_dig(row, f["published"])) if f.get("published") else None,
            updated=to_date(_dig(row, f["updated"])) if f.get("updated") else None,
            summary=_clean(str(_dig(row, f["summary"]) or "")) if f.get("summary") else "",
        ))
    return out


PARSERS = {"rss": parse_rss, "html": parse_html, "json": parse_json}


def page_text(content: bytes) -> list[str]:
    """Tekst strony jako lista niepustych linii (do diffu)."""
    soup = BeautifulSoup(content, "html.parser")
    for t in soup(["script", "style", "noscript", "nav", "footer", "header"]):
        t.decompose()
    lines = (re.sub(r"\s+", " ", ln).strip() for ln in soup.get_text("\n").splitlines())
    return [ln for ln in lines if len(ln) > 3]
