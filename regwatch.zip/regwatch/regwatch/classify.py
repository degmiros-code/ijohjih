"""Klasyfikacja wg taksonomii + wyciąganie pól (stan, data wejścia w życie)."""
from __future__ import annotations
import re
from typing import Optional

import yaml

US_STATES = {
    "AL": "Alabama", "AK": "Alaska", "AZ": "Arizona", "AR": "Arkansas", "CA": "California",
    "CO": "Colorado", "CT": "Connecticut", "DE": "Delaware", "FL": "Florida", "GA": "Georgia",
    "HI": "Hawaii", "ID": "Idaho", "IL": "Illinois", "IN": "Indiana", "IA": "Iowa",
    "KS": "Kansas", "KY": "Kentucky", "LA": "Louisiana", "ME": "Maine", "MD": "Maryland",
    "MA": "Massachusetts", "MI": "Michigan", "MN": "Minnesota", "MS": "Mississippi",
    "MO": "Missouri", "MT": "Montana", "NE": "Nebraska", "NV": "Nevada", "NH": "New Hampshire",
    "NJ": "New Jersey", "NM": "New Mexico", "NY": "New York", "NC": "North Carolina",
    "ND": "North Dakota", "OH": "Ohio", "OK": "Oklahoma", "OR": "Oregon", "PA": "Pennsylvania",
    "RI": "Rhode Island", "SC": "South Carolina", "SD": "South Dakota", "TN": "Tennessee",
    "TX": "Texas", "UT": "Utah", "VT": "Vermont", "VA": "Virginia", "WA": "Washington",
    "WV": "West Virginia", "WI": "Wisconsin", "WY": "Wyoming", "DC": "District of Columbia",
}

EFFECTIVE_RE = re.compile(
    r"(?:effective|takes effect|enters? into force|wchodzi w życie)[^.\d]{0,30}"
    r"(?<!\w)((?:[A-Z][a-z]+ \d{1,2}, \d{4})|(?:\d{1,2} [A-Za-zżźćńółęąśŻŹĆŃÓŁĘĄŚ]+ \d{4})|(?:\d{4}-\d{2}-\d{2}))",
    re.IGNORECASE,
)


def _compile(kw: str) -> re.Pattern:
    prefix = kw.endswith("*")
    core = re.escape(kw.rstrip("*"))
    tail = r"\w*" if prefix else ""
    return re.compile(rf"(?<!\w){core}{tail}(?!\w)", re.IGNORECASE)


class Taxonomy:
    def __init__(self, path: str):
        with open(path, encoding="utf-8") as f:
            raw = yaml.safe_load(f)
        self.topics = [
            (domain, topic, [(kw, _compile(kw)) for kw in kws])
            for domain, topics in raw["domains"].items()
            for topic, kws in topics.items()
        ]
        self.actions = [(a, [_compile(k) for k in kws]) for a, kws in raw["action_types"].items()]

    def classify(self, title: str, summary: str) -> dict:
        text_all = f"{title} {summary}"  # trafienie w tytule waży podwójnie
        scores: dict = {}
        matched: list = []
        for domain, topic, kws in self.topics:
            s = 0
            for kw, rx in kws:
                if rx.search(title):
                    s += 2; matched.append(kw)
                elif rx.search(text_all):
                    s += 1; matched.append(kw)
            if s:
                scores[(domain, topic)] = s
        if not scores:
            return {"domain": None, "topics": [], "keywords": [], "relevance": 0, "action_type": None}
        by_domain: dict = {}
        for (d, _), s in scores.items():
            by_domain[d] = by_domain.get(d, 0) + s
        domain = max(by_domain, key=by_domain.get)
        topics = [t for (d, t), _ in sorted(scores.items(), key=lambda x: -x[1]) if d == domain]
        action = next((a for a, rxs in self.actions if any(r.search(text_all) for r in rxs)), None)
        return {
            "domain": domain, "topics": topics, "keywords": sorted(set(matched)),
            "relevance": sum(scores.values()), "action_type": action,
        }


def state_name(source: dict) -> Optional[str]:
    code = source.get("state")
    if not code:
        j = source.get("jurisdiction", "")
        code = j.split("-", 1)[1] if j.startswith("US-") and j != "US-Federal" else None
    return US_STATES.get(code) if code else None


def effective_date(text: str) -> Optional[str]:
    from .extract import to_date
    m = EFFECTIVE_RE.search(text)
    return to_date(m.group(1)) if m else None
